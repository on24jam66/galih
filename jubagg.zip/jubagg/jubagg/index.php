<?php
include 'class.php';
$init = new RndyTech;
echo
"


_   _       ____                     __     _____
| \ | | __ _/ ___| _ __   __ _ _ __ __\ \   / / _ \
|  \| |/ _` \___ \| '_ \ / _` | '_ ` _ \ \ / / (_) |
| |\  | (_| |___) | |_) | (_| | | | | | \ V / \__, |
|_| \_|\__, |____/| .__/ \__,_|_| |_| |_|\_/    /_/
       |___/      |_|

";
echo "\n";
$z = 0;
$h = "\e[0;32m";
$p = "\e[1;37m";
sleep(2);
echo "╔╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤\n";
echo "╟\n";
echo "╟> URL  >_: ";
$website = trim(fgets(STDIN));
echo "╟> Msg  >_: ";
$pesan = trim(fgets(STDIN));
echo "╟> Amount  >_: ";
$batas = trim(fgets(STDIN));
echo "╟\n";
echo "╟\n";
echo "╚╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧\n";
echo "╔╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤\n";
echo "╟\n";
echo "╟> URL : $website \n";
echo "╟> Ip Address : 185.63.253.200 \n";
echo "╟> Status : 200 \n";
echo "╟> Reason : OK \n";
echo "╟> Able To Spam : $h Yes $p\n";
echo "╟\n";
echo "╚╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧\n";
echo "╔╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤\n";
echo "╟\n";
echo "╟> Continue Spam Y/N : ";
$Jwb = trim(fgets(STDIN));
echo "╟\n";
echo "╚╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧\n";
sleep(2);
$y = 1;
$msg = "AutoRessByRndyTech";
while($y <= $batas)
{
    echo ''.$init->RndySpam($website,$msg);
    if($y == $batas){
    echo "+\n";
    echo "=> $batas Result Terkirim ® RndyTech \n";
    echo "+\n";
    echo "+++++++++++++++++++++++++++++++++++++++++++++++++++\n";
    }
 $y++;
}
?>