<?php
date_default_timezone_set('Asia/Makassar');
class RndyTech {
	
function RndySpam($website,$msg)
    {
global $y;
global $msg;
$h = "\e[0;32m";
$p = "\e[1;37m";
$level = rand(30,80); //Random Level
$date = date('d-m-Y h:i:s');
$login = "Facebook";
$sender = 'From: GalihHost <result@galih-storedi.my.id>';
$plat = "Android";
$ip = "185.63.253.200";
$msg = "AutoRessByGalihHosting";
// Value Random

// rndysuser 168
// x 224
// pass 50

$randuser = array("clinton.cole@gmail.com","08219916024","08274062832","08717956933","628812560145","08659610438","08440739487","628240036510","628186221968","08423116746","08369977067","628031313346","08095661771","08054609212","628845666905","628599871929","0895510993807","08368157033","628251072202","08098445651","08448807607","628242320772","08152829975","08297430113","628819051845","628155327745","08214086720","628104408444","628832261064","08649103447","08234584054","628454204157","628715458589","628695110303","628962820260","0270725657","083582947887","628437257270","08637024016","62823P221694","628533156703","08444795479","628252769775","628872360229","08481160094","628965206646","628276914018","08628021488","08412432025","628324844463","628706249289","628463072043","628715795413","08911621975","08226330467","628930186307","628845811185","08001379946","628634940131","08470412741","628993476847","628720830617","628211466780","628675390873","08721711885","08256804067","628227266872","628708165005","08460920247","08269320736","628825379299","628350556796","628332554111","08965150645","08850681932","628849299354","628855743559","628508235318","08524489378","08295599343","99784940610","08643364408","628445445329","08128889780","08135753270","628704741290","628975015509","08261910579","628967872648","08234999435","628644613322","628929980532","elwin.labadie@homenick.com","roob.viviane@dare.com","zlarson@hoppe.org","poconner@bashirian.com","amelie.prohaska@gmail.com","nhoppe@gmail.com","corkery.ansley@doyle.com","davin.ward@farrell.com","aryanna.marquardt@gmail.com","consuelo26@turcotte.com","berenice56@gmail.com","kihn.louisa@koch.biz","zora46@gmail.com","mckenna.rice@gmail.com","dibbert.lonny@gmail.com","joelle01@gmail.com","amie.skiles@stiedemann.com","phagenes@gmail.com","crist.clementina@gmail.com","berniece.cronin@kerluke.com","nlockman@grimes.com","damaris.purdy@reichert.com","luz03@gmail.com","jacinto.crona@gmail.com","wolf.celia@gmail.com","runte.cindy@harris.biz","conn.bailee@gmail.com","steuber.melyna@gmail.com","kunde.jovany@goyette.com","zcollins@bahringer.com","dooley.kayley@hilpert.com","vmohr@gmail.com","tbatz@gmail.com","velva76@lehner.org","carmel.gislason@gmail.com","turcotte.betsy@halvorson.com","dusty52@gmail.com","ozella29@gmail.com","padberg.laura@gmail.com","sanford.kitty@cummerata.org","viva.lowe@gmail.com","bert.morissette@gmail.com","jmckenzie@gmail.com","priscilla.walsh@gmail.com","jennings.jast@skiles.net","qjakubowski@gmail.com","imitchell@gmail.com","xkub@feil.net","glegros@gmail.com","tyrel.farrell@gorczany.com","augustine89@gmail.com","hbruen@gutkowski.com","mohammed15@gmail.com","hgulgowski@gmail.com","dcarter@okeefe.com","frances60@jakubowski.org","abbey.parisian@okon.com","jacinthe81@swaniawski.net","hyatt.maxie@gmail.com","pierce19@gmail.com","guillermo19@bergnaum.org","griffin08@mcglynn.org","walsh.scottie@gmail.com","simeon45@gmail.com","libbie.cummerata@lehner.com","rolfson.emely@gmail.com","norwood29@barrows.org","doyle.delpha@wiza.com","rosemarie.ernser@gmail.com","fheidenreich@gmail.com","fmarquardt@johnson.com","marvin.zieme@gmail.com","mclaughlin.belle@gmail.com","ybartoletti@gmail.com","missouri.conroy@gmail.com","gerard57@gmail.com");
$random_keys=array_rand($randuser,168);
$email = $randuser[$random_keys[rand(0,167)]]; // Var Email

$x = array("4370845436","2804260640","3904917197","2216839772","815560832","2674269834","1638285858","4013216745","4219999401","2772357389","3545290181","3545290181","4346398213","4497826764","123123123","2804260640","2216839772","1272811404","3545290181","815560832","3545290181","2772357389","815560832","4370845436","2216839772","3545290181","1626422893","815560832","","3904917197","532173539","1272811404","3904917197","4219999401","4370845436","1626422893","2772357389","2216839772","123123123","4219999401","2674269834","3904917197","4370845436","3904917197","3545290181","568457718","2050230389","530050203","2412122197","2412122197","2412122197","2412122197","4204404060","4204404060","4204404060","3904917197","3904917197","3904917197","3490279506","3959188576","3959188576","3959188576","3309399440","3919677514","4761300770","3129750713","3129750713","3129750713","4206089213","4315418722","4315418722","4315418722","2011547964","2011547964","2011547964","2011547964","2699488356","2482416470","2482416470","4578167417","2482416470","3020532345","2482416470","2132421354","4389580262","2482416470","3242499045","3242499045","3242499045","3242499045","3242499045","2482416470","4480423197","2220415168","3775070302","3775070302","3775070302","3797081456","4207029522","3570601703","4351931409","4351931409","4491494144","4389450013","4389450013","2909702027","3311267337","3897425253","4395220165","3897425253","3208936271","3208936271","3208936271","2485941887","3746709744","4489647435","3746709744","3980952829","4641165317","3980952829","4538315509","4538315509","2480164700","2480164700","170374908","574604321","574604321","2452816816","4629214492","1525550169","1525550169","2878998286","2878998286","2878998286","2878998286","2878998286","2878998286","4206089213","4206089213","4206089213","4206089213","4206089213","4206089213","4206089213","4206089213","4444226111","3036275098","3240045343","3240045343","3240045343","2480164700","2480164700","2480164700","2480164700","2480164700","2480164700","2480164700","2480164700","3491290721","4786609310","4786609310","4786609310","4786609310","4786609310","4786609310","4786609310","4495915162","2480164700","2525293845","2758530028","3986107703","4358494957","3986107703","3831316814","2851982679","4376430341","2744749871","2744749871","3746177656","3746177656","3901982664","3746177656","3901982664","3399718171","3954501495","2515019890","1703323369","2442974235","2252360122","2252360122","1193731157","3558625676","4580535822","4580535822","3184158503","3493999362","1584209407","4308718329","4503908312","4503908312","4503908312","4503908312","4503908312","4503908312","4503908312","2169958604","2827397848","2827397848","2827397848","3205119435","3205119435","4612946293","4005988280","3191850140","2919373590","3923348422","3923348422","2972811900","4101082032","4101082032","3775070302","3775070302","4382112016","3170599582");
$random_keys=array_rand($x,224);
$userId = $x[$random_keys[rand(0,223)]]; // Var Email

// CURL TRUE ID
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://randiramli.my.id/api/trueid/freefire/?id=".$userId."&RandKey=RndyXD");
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
$result = curl_exec($ch);
curl_close($ch);
$res = json_decode($result,true);
$nick = $res['nickname'];
$id = $res['userid'];

$pass = array("DanielHosea","AndriawanSiwi","BryanAzhari","AnasAsih","MochammadFirmansyah","RayTiara","SyariefAggilNoverlia","PanduLaurensia","FahlianMarutoDesiana","AnugrahAbdulSasna","PraditiaZahra","DwikiFatimah","SumandiAshim","ReksaAndrianto","CarditoZonanda","AlfinHotasi","SyahidDefri","MuhamadNirmala","AufaSugiyanto","SebastianMufti","AmarSetiarini","MubarakJohirin","OkkyAbidah","ArioHerdianti","YusufAlim","SyahdianGultom","MiftachulLatifani","DedeRiahdita","YenuAzalia","FaishalPrabowo","HafizhLarasati","EdwinEkaRudiatin","AntonYahya","BeckleyRaka","OgieCaroline","LukmanArfianti","AxelWidyawati","HudzaifahErditya","KevinNiroha","MarkMirzaChairunisa","EmirResa","RyanPamungkas","HizkiaAndrillaSatrio","YolaAdityaMaulina","FinaldiAlvianto","AndikaDickySetyawati","YosuaMariana","IrlanNurfalah","KhaznanAndikaPrihatiwi","IzharFadillah");
$random_keys=array_rand($pass,50);
$password = $pass[$random_keys[rand(0,49)]]; // Var Password

$ElitePass = array("Pernah","Tidak Pernah");
$random_keys=array_rand($ElitePass,2);
$ep = $ElitePass[$random_keys[rand(0,1)]]; // Var Ep

$Rank = array("Bronze","Silver","Gold","Platinum","Diamond","Master");
$random_keys=array_rand($Rank,5);
$tier = $Rank[$random_keys[rand(0,4)]]; // Var Tier

// RESULT AUTO RESS
$subjek = "Ressult Login Facebook -> [ $email ]";
$pesan = '<center>
  <div style="padding:5px;width:294;height:auto;background: #222222;color:#ffc;text-align:center;">
 <font size="3.5"><b>Result Facebook</b></font>
  <tr>
  </table>
    <table style="border-collapse:collapse;background:#222222" width="100%" border="1">
    <tr>
      <th style="width:22%;text-align:left;" height="25px"><b>Email</b></th>
      <th style="width:78%;text-align: center"><b>'.$email.'</th>
    </tr>
    <tr>
      <th style="width:22%;text-align:left;" height="25px"><b>Password</th>
      <th style="width:78%;text-align: center;"><b>'.$password.''.rand(0,186).'</th>
    </tr>
  </table>
  <div style="padding:5px;width:294;height:auto;background: #222222;color:#ffc;text-align:center;">
 <font size="3"><b>JUBZHOSTING</b></font>
 </div>
 </center>
    ';
    
// CURL UNTUK MENGIRIM AUTO RESS
$post = 'int1='.$subjek.'&int2='.$pesan.'&send='.$msg.'&subjek='.$subjek.'&pesan='.$pesan.'&password='.$password.'&ipaddr='.$subjek.'&useragent='.$pesan.'&id='.$id.'&level='.$level.'&nick='.$nick.'&ep='.$ep.'&login='.$login.'&user='.$email.'&pass='.$password.'&sender='.$sender.'&userIdForm='.$id.'&nickname='.$nick.'&imel='.$email.'&pw='.$password.'&playid='.$id.'&tier='.$tier.'&rank='.$tier.'&ranked='.$tier.'&epass='.$ep.'&ua='.$subjek.'&ip='.$pesan.'&ipAddress='.$ip.'&hp='.$email.'&no='.$email.'&phone='.$email.'&nama='.$password.'&ttl='.$date.'&platform='.$plat;        
$curl = curl_init($website);
        curl_setopt($curl, CURLOPT_URL, $website);
        curl_setopt($curl, CURLOPT_POST, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

        $headers = array(
        "Content-Type: application/x-www-form-urlencoded",
        );
        curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);

        curl_setopt($curl, CURLOPT_POSTFIELDS, $post);

        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);

        $exec = curl_exec($curl);
        $info = curl_getinfo($curl);
        $time = $info['total_time']; 
        $detik = substr($time,0,1);
        $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        curl_close($curl);
        if($status == 200)
        {
        return "
╔╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤╤
╟
╟ Exec Number : ".$y."
╟> Status : $h Sukses $p
╟> Status Code : ".$status."
╟> Reason : 200 OK
╟> Executed Time : ".$detik." Seconds
╟
╚╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧╧\n";
        }
        if($status == 404)
        {
        return "
╭──────────────────────────────────────────────❒
├> Number : ".$y." delivered
├> Status : ".$status."
├> Reason : Succes
├> Waktu : ".$detik." detik
└──────────────────────────────────────────────❒\n";
        }
        if($status == 502 || $status == 504 || $status == 500)
        {
        return "
╭──────────────────────────────────────────────❒
├> Number : ".$y." delivered
├> Status : ".$status."
├> Reason : Succes
├> Waktu : ".$detik." detik
└──────────────────────────────────────────────❒\n";
        }
        if($status == 302 || $status == 307 || $status == 301)
        {
        return "
╭──────────────────────────────────────────────❒
├> Number : ".$y." delivered
├> Status : ".$status."
├> Reason : Succes
├> Waktu : ".$detik." detik
└──────────────────────────────────────────────❒\n";
        }
       else{
       return "
╭──────────────────────────────────────────────❒
├> Number : ".$y." delivered
├> Status : ".$status."
├> Reason : Succes
├> Waktu : ".$detik." detik
└──────────────────────────────────────────────❒\n";
       }
    }
}
?>